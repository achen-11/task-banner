<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import draggable from 'vuedraggable'
import { useProjectStore } from '@/stores/project'
import { useTaskStore } from '@/stores/task'
import { useDBStore } from '@/stores/db'
import type { Task, TaskStatus } from '@/types'
import TaskDialog from '@/components/TaskDialog.vue'
import ExportDialog from '@/components/ExportDialog.vue'
import ImportDialog from '@/components/ImportDialog.vue'
import ListView from '@/components/ListView.vue'
import { exportTasksToMarkdown, copyToClipboard, importTasksFromMarkdown } from '@/utils/export'

const route = useRoute()
const router = useRouter()
const projectStore = useProjectStore()
const taskStore = useTaskStore()
const dbStore = useDBStore()

const projectId = computed(() => route.params.projectId as string)
const project = computed(() => projectStore.getProjectById(projectId.value))

const showTaskDialog = ref(false)
const showExportDialog = ref(false)
const showImportDialog = ref(false)
const editingTask = ref<Task | null>(null)
const selectedTasks = ref<Set<string>>(new Set())
const viewMode = ref<'board' | 'list'>('list') // 视图模式：看板或列表

// 检测操作系统
const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0
const modKey = isMac ? '⌘' : 'Ctrl'
const altKey = isMac ? '⌥' : 'Alt'

// 任务列状态配置
const columns = [
  { status: 'todo' as TaskStatus, label: '待办', color: 'bg-gray-100' },
  { status: 'in_progress' as TaskStatus, label: '进行中', color: 'bg-blue-100' },
  { status: 'completed' as TaskStatus, label: '已完成', color: 'bg-green-100' },
  { status: 'needs_optimization' as TaskStatus, label: '需优化', color: 'bg-orange-100' },
]

// 优先级颜色映射
const priorityColorMap: Record<string, string> = {
  low: 'text-gray-600',
  medium: 'text-blue-600',
  high: 'text-orange-600',
  urgent: 'text-red-600',
}

// 优先级标签映射
const priorityLabelMap: Record<string, string> = {
  low: '低',
  medium: '中',
  high: '高',
  urgent: '紧急',
}

// 预定义标签颜色映射
const tagColorMap: Record<string, string> = {
  '功能': 'primary',
  'UI': 'success',
  '优化': 'warning',
  'Bug': 'danger',
  '文档': 'info',
  '测试': '',
  '重构': '',
}

// 获取标签颜色类型
const getTagType = (tag: string): '' | 'success' | 'warning' | 'danger' | 'info' | 'primary' => {
  return (tagColorMap[tag] || '') as '' | 'success' | 'warning' | 'danger' | 'info' | 'primary'
}

// 按状态获取任务
const getTasksByStatus = (status: TaskStatus) => {
  return taskStore.getTasksByStatus(projectId.value, status)
}

// 拖拽结束处理
const onDragEnd = async (status: TaskStatus) => {
  const tasks = getTasksByStatus(status)
  tasks.forEach((task: Task, index: number) => {
    // 深度克隆 changelog
    const clonedChangelog = Array.isArray(task.changelog)
      ? task.changelog.map(entry => ({
          timestamp: entry.timestamp,
          field: entry.field,
          oldValue: entry.oldValue,
          newValue: entry.newValue,
          action: entry.action
        }))
      : []

    // 创建纯对象用于保存，避免克隆响应式对象
    const updatedTask: Task = {
      id: task.id,
      projectId: task.projectId,
      title: task.title,
      description: task.description,
      status: status,
      priority: task.priority,
      tags: [...task.tags],
      technicalPoints: task.technicalPoints ? [...task.technicalPoints] : undefined,
      referenceLinks: task.referenceLinks ? [...task.referenceLinks] : undefined,
      progress: task.progress !== undefined ? task.progress : 0,
      changelog: clonedChangelog,
      order: index,
      createdAt: task.createdAt,
      updatedAt: Date.now(),
    }
    taskStore.updateTask(task.id, { order: index, status })
    dbStore.saveTask(updatedTask)
  })
}

// 创建任务
const createTask = () => {
  editingTask.value = null
  showTaskDialog.value = true
}

// 编辑任务
const editTask = (task: Task) => {
  editingTask.value = task
  showTaskDialog.value = true
}

// 删除任务
const deleteTask = async (task: Task) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除任务"${task.title}"吗？`,
      '删除确认',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
    )

    taskStore.deleteTask(task.id)
    await dbStore.removeTask(task.id)
    ElMessage.success('任务删除成功')
  } catch (error) {
    // 用户取消删除
  }
}

// 切换任务选中状态
const toggleTaskSelection = (taskId: string) => {
  if (selectedTasks.value.has(taskId)) {
    selectedTasks.value.delete(taskId)
  } else {
    selectedTasks.value.add(taskId)
  }
}

// 获取当前项目的所有任务
const allProjectTasks = computed(() => {
  return taskStore.getTasksByProject(projectId.value)
})

// 获取排序后的任务列表（用于列表视图）
const sortedProjectTasks = computed(() => {
  const tasks = [...taskStore.getTasksByProject(projectId.value)]

  return tasks.sort((a, b) => {
    // 已完成的任务排在后面
    if (a.status === 'completed' && b.status !== 'completed') return 1
    if (a.status !== 'completed' && b.status === 'completed') return -1

    // 相同状态下，按更新时间降序排序（最新的在前）
    return b.updatedAt - a.updatedAt
  })
})

// 获取选中的任务列表
const getSelectedTasks = computed(() => {
  return taskStore.tasks.filter(task => selectedTasks.value.has(task.id))
})

// 切换全选
const toggleAllSelection = () => {
  const allIds = allProjectTasks.value.map(t => t.id)
  if (allIds.every(id => selectedTasks.value.has(id))) {
    // 如果全选了，则取消全选
    allIds.forEach(id => selectedTasks.value.delete(id))
  } else {
    // 否则全选
    allIds.forEach(id => selectedTasks.value.add(id))
  }
}

// 批量导出任务
const exportTasks = () => {
  if (selectedTasks.value.size === 0) {
    ElMessage.warning('请先选择要导出的任务')
    return
  }
  showExportDialog.value = true
}

// 导入任务
const importTasks = () => {
  showImportDialog.value = true
}

// 导入成功处理
const handleImportSuccess = (importedTasks: Task[]) => {
  ElMessage.success(`成功导入 ${importedTasks.length} 个任务`)
  // 清空选中状态
  selectedTasks.value.clear()
}

// 返回项目列表
const goBack = () => {
  router.push('/projects')
}

const handleTaskDialogSuccess = (taskId: string) => {
  // 任务创建/更新成功后，自动选中该任务
  // 清空之前的选中状态，只选中当前任务
  selectedTasks.value.clear()
  selectedTasks.value.add(taskId)
}

// Cmd+E 导出选中任务
const handleExportShortcut = async () => {
  // 如果 TaskDialog 打开，则由 TaskDialog 处理
  if (showTaskDialog.value) {
    return
  }

  // 导出选中的任务
  if (selectedTasks.value.size === 0) {
    ElMessage.warning('请先选择要导出的任务')
    return
  }

  const tasks = getSelectedTasks.value
  if (!project.value) return

  const markdown = exportTasksToMarkdown(tasks, project.value)
  const success = await copyToClipboard(markdown)

  if (success) {
    ElMessage.success(`已复制 ${tasks.length} 个任务到剪贴板`)
  } else {
    ElMessage.error('复制失败，请重试')
  }
}

// Cmd+I 导入任务（带二次确认）
const handleImportShortcut = async () => {
  try {
    // 读取剪贴板
    const clipboardText = await navigator.clipboard.readText()

    if (!clipboardText.trim()) {
      ElMessage.warning('剪贴板为空')
      return
    }

    // 尝试解析任务（不传递 existingTaskIds，保留原始 task-id）
    const parsedTasks = importTasksFromMarkdown(clipboardText, projectId.value, [])

    if (parsedTasks.length === 0) {
      ElMessage.error('无法识别剪贴板内容，请确保格式正确')
      return
    }

    // 检查哪些任务是更新，哪些是新建
    const existingTaskMap = new Map(taskStore.tasks.map(t => [t.id, t]))
    const tasksToUpdate: Partial<Task>[] = []
    const tasksToCreate: Partial<Task>[] = []

    parsedTasks.forEach(taskData => {
      if (taskData.id && existingTaskMap.has(taskData.id)) {
        tasksToUpdate.push(taskData)
      } else {
        tasksToCreate.push(taskData)
      }
    })

    // 显示确认对话框，列出任务标题和操作
    const confirmLines: string[] = []
    if (tasksToUpdate.length > 0) {
      confirmLines.push(`📝 更新 ${tasksToUpdate.length} 个任务：`)
      tasksToUpdate.forEach((t, i) => {
        confirmLines.push(`  ${i + 1}. ${t.title}`)
      })
    }
    if (tasksToCreate.length > 0) {
      if (tasksToUpdate.length > 0) confirmLines.push('')
      confirmLines.push(`✨ 新建 ${tasksToCreate.length} 个任务：`)
      tasksToCreate.forEach((t, i) => {
        confirmLines.push(`  ${i + 1}. ${t.title}`)
      })
    }
    confirmLines.push('\n按回车确认导入')

    await ElMessageBox.confirm(
      confirmLines.join('\n'),
      '确认导入',
      {
        confirmButtonText: '确认导入',
        cancelButtonText: '取消',
        type: 'info',
        distinguishCancelAndClose: true,
      }
    )

    // 更新已存在的任务
    for (const taskData of tasksToUpdate) {
      const existingTask = existingTaskMap.get(taskData.id!)!
      const updatedTask: Task = {
        ...existingTask,
        title: taskData.title || existingTask.title,
        description: taskData.description || existingTask.description,
        status: taskData.status || existingTask.status,
        priority: taskData.priority || existingTask.priority,
        // 确保数组是纯 JavaScript 数组，避免 DataCloneError
        tags: taskData.tags ? [...taskData.tags] : [...existingTask.tags],
        technicalPoints: taskData.technicalPoints ? [...taskData.technicalPoints] : (existingTask.technicalPoints ? [...existingTask.technicalPoints] : undefined),
        referenceLinks: taskData.referenceLinks ? [...taskData.referenceLinks] : (existingTask.referenceLinks ? [...existingTask.referenceLinks] : undefined),
        progress: taskData.progress !== undefined ? taskData.progress : existingTask.progress,
        // 优先使用导入内容中的 changelog，如果没有则保留现有的
        changelog: taskData.changelog && taskData.changelog.length > 0
          ? taskData.changelog.map(entry => ({
              timestamp: entry.timestamp || Date.now(),
              field: entry.field || '',
              oldValue: entry.oldValue || '',
              newValue: entry.newValue || '',
              action: entry.action || ''
            }))
          : (existingTask.changelog ? existingTask.changelog.map(entry => ({
              timestamp: entry.timestamp,
              field: entry.field,
              oldValue: entry.oldValue,
              newValue: entry.newValue,
              action: entry.action
            })) : []),
        updatedAt: Date.now(),
      }
      taskStore.updateTask(taskData.id!, updatedTask)
      await dbStore.saveTask(updatedTask)
    }

    // 创建新任务
    for (const taskData of tasksToCreate) {
      const task: Task = {
        id: taskData.id || `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        projectId: projectId.value,
        title: taskData.title || '',
        description: taskData.description || '',
        status: taskData.status || 'todo',
        priority: taskData.priority || 'medium',
        // 确保数组是纯 JavaScript 数组
        tags: taskData.tags ? [...taskData.tags] : [],
        technicalPoints: taskData.technicalPoints ? [...taskData.technicalPoints] : undefined,
        referenceLinks: taskData.referenceLinks ? [...taskData.referenceLinks] : undefined,
        progress: taskData.progress || 0,
        // 确保 changelog 是纯数组
        changelog: taskData.changelog ? taskData.changelog.map(entry => ({
          timestamp: entry.timestamp || Date.now(),
          field: entry.field || '',
          oldValue: entry.oldValue || '',
          newValue: entry.newValue || '',
          action: entry.action || ''
        })) : [],
        order: taskData.order || taskStore.tasks.length,
        createdAt: taskData.createdAt || Date.now(),
        updatedAt: Date.now(),
      }
      taskStore.addTask(task)
      await dbStore.saveTask(task)
    }

    const message = []
    if (tasksToUpdate.length > 0) message.push(`更新 ${tasksToUpdate.length} 个`)
    if (tasksToCreate.length > 0) message.push(`新建 ${tasksToCreate.length} 个`)
    ElMessage.success(`成功${message.join('，')}任务`)
    selectedTasks.value.clear()
  } catch (error: any) {
    if (error === 'cancel' || error === 'close') {
      // 用户取消
      return
    }
    console.error('导入失败:', error)
    ElMessage.error('导入失败，请检查剪贴板内容格式')
  }
}

// 快捷键处理
function handleKeyDown(event: KeyboardEvent) {
  // Option+N (Mac) 或 Alt+N (Windows/Linux) 新建任务
  console.log(event)
  if (event.altKey && event.code === 'KeyN') {
    event.preventDefault()
    console.log('createTask')
    createTask()
  }
  // Cmd+E (Mac) 或 Ctrl+E (Windows/Linux) 导出
  else if ((event.metaKey || event.ctrlKey) && event.key === 'e') {
    event.preventDefault()
    handleExportShortcut()
  }
  // Cmd+I (Mac) 或 Ctrl+I (Windows/Linux) 导入
  else if ((event.metaKey || event.ctrlKey) && event.key === 'i') {
    event.preventDefault()
    handleImportShortcut()
  }
}

onMounted(() => {
  window.addEventListener('keydown', handleKeyDown)
})

onUnmounted(() => {
  window.removeEventListener('keydown', handleKeyDown)
})
</script>

<template>
  <div class="min-h-screen bg-gray-50">
    <div class="container mx-auto px-6 py-8">
      <!-- 顶部工具栏 -->
      <div class="mb-8">
        <div class="flex items-center justify-between mb-6">
          <div class="flex items-center gap-4">
            <el-button @click="goBack">
              ← 返回
            </el-button>
            <div v-if="project">
              <h1 class="text-3xl font-bold text-gray-900">{{ project.name }}</h1>
              <p class="text-gray-600 mt-1">{{ project.description }}</p>
            </div>
          </div>
          <div class="flex gap-2">
            <!-- 视图切换按钮 -->
            <el-button-group>
              <el-button
                :type="viewMode === 'board' ? 'primary' : ''"
                @click="viewMode = 'board'"
              >
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 16a1 1 0 011-1h4a1 1 0 011 1v3a1 1 0 01-1 1H5a1 1 0 01-1-1v-3zM14 16a1 1 0 011-1h4a1 1 0 011 1v3a1 1 0 01-1 1h-4a1 1 0 01-1-1v-3z"></path>
                </svg>
              </el-button>
              <el-button
                :type="viewMode === 'list' ? 'primary' : ''"
                @click="viewMode = 'list'"
              >
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
              </el-button>
            </el-button-group>

            <el-tooltip :content="`快捷键: ${modKey}+I`" placement="bottom">
              <el-button
                type="info"
                @click="importTasks"
              >
                导入任务
              </el-button>
            </el-tooltip>
            <el-tooltip v-if="selectedTasks.size > 0" :content="`快捷键: ${modKey}+E`" placement="bottom">
              <el-button
                type="success"
                @click="exportTasks"
              >
                导出选中 ({{ selectedTasks.size }})
              </el-button>
            </el-tooltip>
            <el-tooltip :content="`快捷键: ${altKey}+N`" placement="bottom">
              <el-button
                type="primary"
                @click="createTask"
              >
                新建任务
              </el-button>
            </el-tooltip>
          </div>
        </div>

        <!-- 技术栈标签 -->
        <div v-if="project" class="flex gap-2">
          <el-tag
            v-for="tech in project.techStack"
            :key="tech"
            type="info"
            size="small"
          >
            {{ tech }}
          </el-tag>
        </div>
      </div>

      <!-- 看板视图 -->
      <div v-if="viewMode === 'board'" class="grid grid-cols-4 gap-6">
        <div
          v-for="column in columns"
          :key="column.status"
          class="flex flex-col"
        >
          <div :class="['rounded-t-xl p-4 font-semibold', column.color]">
            <div class="flex justify-between items-center">
              <span>{{ column.label }}</span>
              <span class="text-sm opacity-75">{{ getTasksByStatus(column.status).length }}</span>
            </div>
          </div>

          <div class="bg-white rounded-b-xl p-3 flex-1 min-h-[600px] shadow-sm">
            <draggable
              :list="getTasksByStatus(column.status)"
              group="tasks"
              item-key="id"
              class="space-y-3 min-h-full"
              @end="onDragEnd(column.status)"
            >
              <template #item="{ element: task }">
                <div
                  :class="[
                    'bg-white border rounded-xl p-4 cursor-move hover:shadow-lg transition-all duration-200',
                    selectedTasks.has(task.id) ? 'border-blue-400 shadow-md ring-2 ring-blue-100' : 'border-gray-200 hover:border-gray-300'
                  ]"
                  @click="toggleTaskSelection(task.id)"
                >
                  <div class="flex justify-between items-start mb-3">
                    <h3 class="font-semibold text-gray-900 text-base flex-1 line-clamp-2 leading-relaxed">
                      {{ task.title }}
                    </h3>
                    <el-checkbox
                      :model-value="selectedTasks.has(task.id)"
                      @click.stop
                      @change="toggleTaskSelection(task.id)"
                    />
                  </div>

                  <p class="text-gray-600 text-sm mb-4 line-clamp-3 leading-relaxed" :title="task.description">
                    {{ task.description }}
                  </p>

                  <div class="flex flex-wrap gap-2 mb-3">
                    <el-tag
                      v-for="tag in task.tags"
                      :key="tag"
                      size="small"
                      :type="getTagType(tag)"
                    >
                      {{ tag }}
                    </el-tag>
                    <!-- 迭代标记 -->
                    <el-tag
                      v-if="task.changelog && task.changelog.length > 0"
                      size="small"
                      effect="dark"
                      class="iteration-badge"
                    >
                      🔄 v{{ task.changelog.length }}
                    </el-tag>
                  </div>

                  <div class="flex justify-between items-center text-xs">
                    <span :class="priorityColorMap[task.priority]">
                      {{ priorityLabelMap[task.priority] }}
                    </span>
                    <div class="flex gap-1" @click.stop>
                      <el-button
                        size="small"
                        text
                        type="primary"
                        @click="editTask(task)"
                      >
                        编辑
                      </el-button>
                      <el-button
                        size="small"
                        text
                        type="danger"
                        @click="deleteTask(task)"
                      >
                        删除
                      </el-button>
                    </div>
                  </div>
                </div>
              </template>
            </draggable>
          </div>
        </div>
      </div>

      <!-- 列表视图 -->
      <ListView
        v-if="viewMode === 'list'"
        :tasks="sortedProjectTasks"
        :selected-tasks="selectedTasks"
        @toggle-selection="toggleTaskSelection"
        @toggle-all-selection="toggleAllSelection"
        @edit="editTask"
        @delete="deleteTask"
      />

      <!-- 任务对话框 -->
      <TaskDialog
        v-model:visible="showTaskDialog"
        :project-id="projectId"
        :task="editingTask"
        @success="handleTaskDialogSuccess"
      />

      <!-- 导出对话框 -->
      <ExportDialog
        v-model:visible="showExportDialog"
        :tasks="getSelectedTasks"
        :project="project || null"
      />

      <!-- 导入对话框 -->
      <ImportDialog
        v-model:visible="showImportDialog"
        :project-id="projectId"
        @success="handleImportSuccess"
      />
    </div>
  </div>
</template>

<style scoped>
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.line-clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}

.iteration-badge {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
  border: none !important;
  font-weight: 600;
}
</style>
